"""Tests for NFL module."""

"""Tests for PFR module."""
